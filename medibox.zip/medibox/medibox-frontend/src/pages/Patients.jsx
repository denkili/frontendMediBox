import Navbar from "../components/Navbar.jsx";
import Sidebar from "../components/Sidebar.jsx";
import { dummyPatients } from "../data/dummyPatients.js";
import PatientCard from "../components/PatientCard.jsx";

const Patients = () => {
  return (
    <div className="flex">
      <Sidebar />

      <div className="flex flex-col flex-1 ml-64">
        <Navbar />

        <div className="p-6">
          <h2 className="text-2xl font-bold mb-6">Pacijenti</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {dummyPatients.map((p) => (
              <PatientCard key={p.id} patient={p} />
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default Patients;
