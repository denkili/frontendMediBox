import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

const Dashboard = () => {
  return (
    <div className="flex">

      {/* Sidebar */}
      <Sidebar />

      <div className="flex flex-col flex-1 ml-64">

        {/* Navbar */}
        <Navbar />

        {/* Dashboard content */}
        <div className="p-6 mt-15">

          <h2 className="text-2xl font-bold mb-4">Dashboard</h2>

          <div className="grid grid-cols-3 gap-6">

            {/* Card 1: broj pacijenata */}
            <div className="p-6 bg-white shadow rounded-lg">
              <p className="text-gray-500">Ukupno pacijenata</p>
              <h3 className="text-3xl font-semibold mt-2">24</h3>
            </div>

            {/* Card 2: zakazane tablete */}
            <div className="p-6 bg-white shadow rounded-lg">
              <p className="text-gray-500">Propisane terapije</p>
              <h3 className="text-3xl font-semibold mt-2">56</h3>
            </div>

            {/* Card 3: danasnje tablete */}
            <div className="p-6 bg-white shadow rounded-lg">
              <p className="text-gray-500">Tablete za danas</p>
              <h3 className="text-3xl font-semibold mt-2">13</h3>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};

export default Dashboard;
