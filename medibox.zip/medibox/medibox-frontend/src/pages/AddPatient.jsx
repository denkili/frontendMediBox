import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Sidebar from "../components/Sidebar.jsx";

const AddPatient = () => {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [condition, setCondition] = useState("");

  const submitHandler = (e) => {
    e.preventDefault();

    if (!name || !age || !condition) {
      alert("Popuni sva polja!");
      return;
    }

    // ✅ Dummy poruka (umjesto backenda)
    alert(`Pacijent "${name}" uspješno dodan u bazu!`);

    // ✅ Preusmjeravanje nazad na listu pacijenata
    navigate("/patients");
  };

  return (
    <div className="flex">
      <Sidebar />

      <div className="flex flex-col flex-1 ml-64">
        <Navbar />

        <div className="p-6 mt-15">
          <h2 className="text-2xl font-bold mb-6">Dodaj novog pacijenta</h2>

          <form
            onSubmit={submitHandler}
            className="bg-white p-6 rounded-lg shadow w-full max-w-lg flex flex-col gap-4"
          >
            <input 
              type="text" 
              placeholder="Ime pacijenta"
              className="border p-3 rounded"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <input 
              type="number" 
              placeholder="Godine"
              className="border p-3 rounded"
              value={age}
              onChange={(e) => setAge(e.target.value)}
            />

            <input 
              type="text" 
              placeholder="Dijagnoza"
              className="border p-3 rounded"
              value={condition}
              onChange={(e) => setCondition(e.target.value)}
            />

            <button className="bg-green-600 text-white p-3 rounded hover:bg-green-700">
              Spasi pacijenta
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddPatient;
