import { useState, useRef } from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

const DoctorProfile = () => {
  const [editMode, setEditMode] = useState(false);
  const fileInputRef = useRef(null);

  const [doctor, setDoctor] = useState({
    name: "Dr. Denis",
    email: "denis@example.com",
    specialization: "Porodična medicina",
    image: "https://i.pravatar.cc/200"
  });

  // ✅ Bira novu sliku
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const imageUrl = URL.createObjectURL(file);

    setDoctor((prev) => ({
      ...prev,
      image: imageUrl
    }));
  };

  // ✅ Čuva izmjene i isključuje edit mode
  const handleSave = () => {
    setEditMode(false);
    alert("Podaci uspješno spremljeni!");
  };

  return (
    <div className="flex">
      <Sidebar />

      <div className="flex flex-col flex-1 ml-64">
        <Navbar />

        <div className="p-6">
          <h2 className="text-2xl font-bold mb-4">Moj profil</h2>

          <div className="bg-white p-6 rounded shadow max-w-lg flex gap-6">

            {/* ✅ SLIKA PROFILA */}
            <div className="relative">
              <img
                src={doctor.image}
                className={`w-28 h-28 rounded-full border cursor-pointer transition 
                ${editMode ? "opacity-50" : ""}`}
                onClick={() => editMode && fileInputRef.current.click()}
              />

              {/* Hidden file input */}
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                className="hidden"
                onChange={handleImageChange}
              />

              {editMode && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <p className="text-xs bg-black bg-opacity-40 text-white px-2 py-1 rounded">
                    Klikni za promjenu
                  </p>
                </div>
              )}
            </div>

            {/* ✅ PODACI */}
            <div className="flex flex-col gap-3 w-full">

              {/* Ime */}
              {editMode ? (
                <div>
                  <label className="font-semibold text-sm">Ime:</label>
                  <input
                    type="text"
                    value={doctor.name}
                    onChange={(e) =>
                      setDoctor({ ...doctor, name: e.target.value })
                    }
                    className="border p-2 rounded w-full"
                  />
                </div>
              ) : (
                <p><b>Ime:</b> {doctor.name}</p>
              )}

              {/* Email */}
              {editMode ? (
                <div>
                  <label className="font-semibold text-sm">Email:</label>
                  <input
                    type="email"
                    value={doctor.email}
                    onChange={(e) =>
                      setDoctor({ ...doctor, email: e.target.value })
                    }
                    className="border p-2 rounded w-full"
                  />
                </div>
              ) : (
                <p><b>Email:</b> {doctor.email}</p>
              )}

              {/* Specijalizacija */}
              {editMode ? (
                <div>
                  <label className="font-semibold text-sm">Specijalizacija:</label>
                  <input
                    type="text"
                    value={doctor.specialization}
                    onChange={(e) =>
                      setDoctor({ ...doctor, specialization: e.target.value })
                    }
                    className="border p-2 rounded w-full"
                  />
                </div>
              ) : (
                <p><b>Specijalizacija:</b> {doctor.specialization}</p>
              )}

              {/* ✅ Dugme za edit / spremanje */}
              {editMode ? (
                <button
                  onClick={handleSave}
                  className="bg-green-600 mt-3 text-white px-4 py-2 rounded hover:bg-green-700"
                >
                  Spremi podatke
                </button>
              ) : (
                <button
                  onClick={() => setEditMode(true)}
                  className="bg-blue-600 mt-3 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  Uredi profil
                </button>
              )}

            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default DoctorProfile;
