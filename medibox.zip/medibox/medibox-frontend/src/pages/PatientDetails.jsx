import { useParams, Link } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Sidebar from "../components/Sidebar.jsx";
import TabletCard from "../components/TabletCard.jsx";
import { dummyPatients } from "../data/dummyPatients.js";
import { dummyMedications } from "../data/dummyMedications.js";
import { useState } from "react";

const PatientDetails = () => {
    const { id } = useParams();

    const [patient, setPatient] = useState(
        dummyPatients.find((p) => p.id == id)
    );

    const [editMode, setEditMode] = useState(false);

    const [meds, setMeds] = useState(
        dummyMedications.filter((m) => m.patientId == id)
    );

    if (!patient) return <div className="ml-64 p-6">Pacijent nije pronađen.</div>;

    // ✅ Brisanje terapije
    const deleteMed = (medId) => {
        setMeds(meds.filter((m) => m.id !== medId));
    };

    // ✅ Spremanje pacijenta
    const savePatient = () => {
        setEditMode(false);
    };

    return (
        <div className="flex">
            <Sidebar />

            <div className="flex flex-col flex-1 ml-64">
                <Navbar />

                <div className="p-6 mt-15" >
                    {/* ✅ Glavni layout — lijevo info, desno dugmad */}
                    <div className="flex justify-between items-start">

                        {/* ✅ Lijeva strana — detalji pacijenta */}
                        <div className="flex-1 max-w-lg">

                            <h2 className="text-2xl font-bold mb-2">{patient.name}</h2>

                            {editMode ? (
                                <div className="bg-white p-4 shadow rounded flex flex-col gap-3">

                                    <div>
                                        <label className="font-semibold text-sm">Ime:</label>
                                        <input
                                            type="text"
                                            className="border p-2 rounded w-full"
                                            value={patient.name}
                                            onChange={(e) =>
                                                setPatient({ ...patient, name: e.target.value })
                                            }
                                        />
                                    </div>

                                    <div>
                                        <label className="font-semibold text-sm">Godine:</label>
                                        <input
                                            type="number"
                                            className="border p-2 rounded w-full"
                                            value={patient.age}
                                            onChange={(e) =>
                                                setPatient({ ...patient, age: e.target.value })
                                            }
                                        />
                                    </div>

                                    <div>
                                        <label className="font-semibold text-sm">Dijagnoza:</label>
                                        <input
                                            type="text"
                                            className="border p-2 rounded w-full"
                                            value={patient.condition}
                                            onChange={(e) =>
                                                setPatient({ ...patient, condition: e.target.value })
                                            }
                                        />
                                    </div>

                                    <button
                                        className="mt-2 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                                        onClick={savePatient}
                                    >
                                        Spremi pacijenta
                                    </button>
                                </div>
                            ) : (
                                <div className="bg-white p-4 shadow rounded">
                                    <p className="text-gray-700"><b>Ime:</b> {patient.name}</p>
                                    <p className="text-gray-700"><b>Godine:</b> {patient.age}</p>
                                    <p className="text-gray-700"><b>Dijagnoza:</b> {patient.condition}</p>
                                </div>
                            )}
                        </div>

                        {/* ✅ Desna strana — dugmad */}
                        <div className="flex flex-col gap-3 mt-11">

                            {/* Dodavanje terapije */}
                            <Link
                                to={`/patients/${patient.id}/add-med`}
                                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-center"
                            >
                                Dodaj terapiju
                            </Link>

                            {/* Uredi pacijenta */}
                            <button
                                className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600"
                                onClick={() => setEditMode(!editMode)}
                            >
                                {editMode ? "Odustani" : "Uredi pacijenta"}
                            </button>
                        </div>

                    </div>

                    {/* ✅ Lista terapija */}
                    <h3 className="text-xl font-semibold mt-10 mb-4">Terapije</h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {meds.map((m) => (
                            <TabletCard key={m.id} med={m} onDelete={deleteMed} />
                        ))}
                    </div>

                    {meds.length === 0 && (
                        <p className="text-gray-500 mt-4">Nema dodanih terapija.</p>
                    )}

                </div>
            </div>
        </div>
    );
};

export default PatientDetails;
