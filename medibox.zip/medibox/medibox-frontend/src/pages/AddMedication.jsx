import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import { dummyPatients } from "../data/dummyPatients";
import { useState } from "react";

const AddMedication = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const patient = dummyPatients.find((p) => p.id == id);

  const [name, setName] = useState("");
  const [dose, setDose] = useState("");
  const [times, setTimes] = useState([""]);

  const addTime = () => setTimes([...times, ""]);
  const removeTime = (i) => setTimes(times.filter((_, index) => index !== i));
  const updateTime = (i, val) => {
    const copy = [...times];
    copy[i] = val;
    setTimes(copy);
  };

  const save = () => {
    if (!name || !dose) {
      alert("Popuni sva polja!");
      return;
    }

    alert(`Dodano za pacijenta: ${patient.name}`);
    navigate(`/patients/${id}`);
  };

  return (
    <div className="flex">
      <Sidebar />

      <div className="flex flex-col flex-1 ml-64">
        <Navbar />

        <div className="p-6 flex justify-center">
          
          {/* ✅ Ovdje dodajemo naslov */}
          <div className="w-full max-w-xl mt-15">
            <h2 className="text-2xl font-bold mb-6 text-center">
              Dodaj terapiju za: {patient?.name}
            </h2>

            <div className="bg-white p-6 rounded shadow flex flex-col gap-4 mt-1">

              <input
                type="text"
                placeholder="Naziv lijeka"
                className="border p-3 rounded"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />

              <input
                type="text"
                placeholder="Doza"
                className="border p-3 rounded"
                value={dose}
                onChange={(e) => setDose(e.target.value)}
              />

              {/* vremena */}
              <div className="flex flex-col gap-2">
                {times.map((t, i) => (
                  <div key={i} className="flex items-center gap-3">

                    <input
                      type="time"
                      className="border p-3 rounded flex-1"
                      value={t}
                      onChange={(e) => updateTime(i, e.target.value)}
                    />

                    {i > 0 && (
                      <button
                        onClick={() => removeTime(i)}
                        className="px-3 py-2 bg-red-700 text-white rounded"
                      >
                        -
                      </button>
                    )}
                  </div>
                ))}

                <button
                  onClick={addTime}
                  className="px-4 py-2 rounded bg-green-600 text-white"
                >
                  + Dodaj vrijeme
                </button>
              </div>

              <button
                onClick={save}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Spasi terapiju
              </button>

            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default AddMedication;
