export const dummyPatients = [
  {
    id: 1,
    name: "Marko Kovač",
    age: 68,
    condition: "Povišen krvni tlak"
  },
  {
    id: 2,
    name: "Ana Marić",
    age: 74,
    condition: "Dijabetes tip 2"
  },
  {
    id: 3,
    name: "Ivan Perić",
    age: 55,
    condition: "Astma"
  },
  {
    id: 4,
    name: "Maja Babić",
    age: 62,
    condition: "Hipertenzija"
  },
  {
    id: 5,
    name: "Nikola Horvat",
    age: 81,
    condition: "Srčana insuficijencija"
  }
];
