export const dummyMedications = [
  {
    id: 1,
    patientId: 1,
    name: "Aspirin",
    dose: "1 tableta",
    time: "08:00"
  },
  {
    id: 2,
    patientId: 1,
    name: "Lisinopril",
    dose: "1 tableta",
    time: "20:00"
  },
  {
    id: 3,
    patientId: 2,
    name: "Metformin",
    dose: "2 tablete",
    time: "08:00"
  },
  {
    id: 4,
    patientId: 2,
    name: "Gliclazide",
    dose: "1 tableta",
    time: "18:00"
  },
  {
    id: 5,
    patientId: 3,
    name: "Ventolin inhaler",
    dose: "2 udaha",
    time: "Po potrebi"
  },
  {
    id: 6,
    patientId: 4,
    name: "Amlodipin",
    dose: "1 tableta",
    time: "09:00"
  },
  {
    id: 7,
    patientId: 5,
    name: "Furosemid",
    dose: "1 tableta",
    time: "07:00"
  }
];
