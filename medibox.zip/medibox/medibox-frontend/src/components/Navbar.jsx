import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";


const Navbar = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("doctorToken");
    navigate("/login");
  };
 

  return (
    <div className="w-full h-16 bg-white shadow flex items-center px-6 justify-between fixed top-0 left-0 z-50">

      <button onClick={()=>navigate("/")} className="text-xl font-semibold cursor-pointer">Medibox</button>

      <div className="relative">
        {/* Avatar */}
        <img
          src="https://i.pravatar.cc/40"
          className="w-10 h-10 rounded-full border cursor-pointer"
          onClick={() => setOpen(!open)}
        />

        {/* Dropdown */}
        {open && (
          <div className="absolute right-0 mt-2 w-40 bg-white shadow rounded border p-2 flex flex-col text-sm">
            
            <Link
              to="/profile"
              className="px-3 py-2 hover:bg-gray-100 rounded"
              onClick={() => setOpen(false)}
            >
              Moj profil
            </Link>

            <button
              className="text-left px-3 py-2 hover:bg-gray-100 rounded"
              onClick={logout}
            >
              Logout
            </button>

          </div>
        )}
      </div>
    </div>
  );
};

export default Navbar;
