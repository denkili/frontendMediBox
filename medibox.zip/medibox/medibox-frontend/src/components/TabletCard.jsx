const TabletCard = ({ med, onDelete }) => {
  return (
    <div className="bg-white p-5 rounded-lg shadow flex justify-between items-start h-full">

      {/* Info o terapiji */}
      <div>
        <p className="text-lg font-semibold">{med.name}</p>
        <p className="text-gray-600">Doza: {med.dose}</p>
        <p className="text-gray-600">Vrijeme:</p>

        {Array.isArray(med.time)
          ? med.time.map((t, i) => (
              <p key={i} className="text-gray-500 ml-2">• {t}</p>
            ))
          : <p className="text-gray-500 ml-2">• {med.time}</p>
        }
      </div>

      {/* Delete dugme */}
      <button
        onClick={() => onDelete(med.id)}
        className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
      >
        Obriši
      </button>

    </div>
  );
};

export default TabletCard;
