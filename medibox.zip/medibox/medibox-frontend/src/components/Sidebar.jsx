import { NavLink } from "react-router-dom";

const Sidebar = () => {
  return (
    <div className="w-64 h-screen bg-gray-900 text-white fixed left-0 top-0 pt-20 shadow-lg">

      <div className="flex flex-col p-4 gap-3 text-gray-300">

        <NavLink
          to="/"
          end
          className={({ isActive }) =>
            `p-3 rounded transition ${
              isActive ? "bg-gray-800 text-white" : "hover:bg-gray-800"
            }`
          }
        >
          Dashboard
        </NavLink>

        <NavLink
          to="/patients"
          end   
          className={({ isActive }) =>
            `p-3 rounded transition ${
              isActive ? "bg-gray-800 text-white" : "hover:bg-gray-800"
            }`
          }
        >
          Pacijenti
        </NavLink>

        <NavLink
          to="/patients/add"
          className={({ isActive }) =>
            `p-3 rounded transition ${
              isActive ? "bg-gray-800 text-white" : "hover:bg-gray-800"
            }`
          }
        >
          Dodaj pacijenta
        </NavLink>

      </div>
    </div>
  );
};

export default Sidebar;
